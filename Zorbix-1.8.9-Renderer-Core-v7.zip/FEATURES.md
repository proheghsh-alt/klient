# Zorbix 1.8.9 renderer core

This build patches the vanilla 1.8.9 rendering pipeline without Forge/Fabric.

Implemented hooks:
- EntityRenderer render pass bootstrap.
- RenderGlobal.updateChunks deadline clamp to prevent chunk compilation/upload spikes from consuming an entire frame.
- ChunkRenderDispatcher.runChunkUploads deadline clamp for the render-thread OpenGL upload queue.
- RenderChunk.resortTransparency spatial-camera filtering to avoid redundant transparency resort tasks.
- RenderGlobal.setupTerrain entry instrumentation matched by method signature (works with MCP/obfuscated names) without skipping dirty-chunk processing.

Targeted pipeline: setupTerrain -> updateChunks -> RenderChunk compile/resort -> ChunkRenderDispatcher upload -> renderBlockLayer.

The project is source-first and must be built/tested in a real 1.8.9 runtime before being called release-ready.
