package com.zorbix.render;

import java.lang.instrument.Instrumentation;

public final class ZorbixAgent {
    public static void premain(String args, Instrumentation instrumentation) {
        ZorbixConfig.load();
        instrumentation.addTransformer(new ZorbixTransformer(), true);
    }
}
