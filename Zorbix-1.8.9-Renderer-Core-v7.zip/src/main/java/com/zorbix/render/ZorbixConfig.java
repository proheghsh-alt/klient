package com.zorbix.render;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public final class ZorbixConfig {
    public static boolean fastRender = true;
    public static boolean smoothFps = true;
    public static boolean fastMath = true;
    public static boolean smartAnimations = true;
    public static boolean clouds = false;
    public static boolean weather = false;
    public static boolean minimalParticles = true;
    public static long chunkUpdateBudgetNs = 3500000L;
    public static long transparencyCoalesceNs = 15000000L;

    private static File file() {
        String home = System.getProperty("user.home", ".");
        return new File(new File(home, ".minecraft/config"), "zorbix.properties");
    }

    public static synchronized void load() {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(file())) {
            p.load(in);
        } catch (Exception ignored) { }
        fastRender = bool(p, "fastRender", true);
        smoothFps = bool(p, "smoothFps", true);
        fastMath = bool(p, "fastMath", true);
        smartAnimations = bool(p, "smartAnimations", true);
        clouds = bool(p, "clouds", false);
        weather = bool(p, "weather", false);
        minimalParticles = bool(p, "minimalParticles", true);
        try { chunkUpdateBudgetNs = Math.max(1000000L, Math.min(12000000L, Long.parseLong(p.getProperty("chunkUpdateBudgetNs", "3500000")))); }
        catch (Exception ignored) { chunkUpdateBudgetNs = 3500000L; }
        try { transparencyCoalesceNs = Math.max(5000000L, Math.min(50000000L, Long.parseLong(p.getProperty("transparencyCoalesceNs", "15000000")))); }
        catch (Exception ignored) { transparencyCoalesceNs = 15000000L; }
        save();
    }

    private static boolean bool(Properties p, String k, boolean d) {
        String v = p.getProperty(k);
        return v == null ? d : Boolean.parseBoolean(v);
    }

    public static synchronized void save() {
        File f = file();
        File parent = f.getParentFile();
        if (!parent.exists()) parent.mkdirs();
        Properties p = new Properties();
        p.setProperty("fastRender", Boolean.toString(fastRender));
        p.setProperty("smoothFps", Boolean.toString(smoothFps));
        p.setProperty("fastMath", Boolean.toString(fastMath));
        p.setProperty("smartAnimations", Boolean.toString(smartAnimations));
        p.setProperty("clouds", Boolean.toString(clouds));
        p.setProperty("weather", Boolean.toString(weather));
        p.setProperty("minimalParticles", Boolean.toString(minimalParticles));
        p.setProperty("chunkUpdateBudgetNs", Long.toString(chunkUpdateBudgetNs));
        p.setProperty("transparencyCoalesceNs", Long.toString(transparencyCoalesceNs));
        try (FileOutputStream out = new FileOutputStream(f)) { p.store(out, "Zorbix 1.8.9"); }
        catch (Exception ignored) { }
    }
}
