package com.zorbix.render;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/** Small, allocation-light runtime controls used by the bytecode patches. */
public final class ZorbixRender {
    private ZorbixRender() {}

    private static final Map<Object, CameraPoint> TRANSPARENCY_CAMERA =
            Collections.synchronizedMap(new WeakHashMap<Object, CameraPoint>());
    private static final Map<Object, Long> TRANSPARENCY_QUEUE =
            Collections.synchronizedMap(new WeakHashMap<Object, Long>());

    private static final class CameraPoint {
        final float x, y, z;
        CameraPoint(float x, float y, float z) {
            this.x = x; this.y = y; this.z = z;
        }
    }

    public static long clampDeadline(long requested) {
        if (!ZorbixConfig.smoothFps || ZorbixConfig.chunkUpdateBudgetNs <= 0L) return requested;
        long now = System.nanoTime();
        long budget = now + ZorbixConfig.chunkUpdateBudgetNs;
        return requested < budget ? requested : budget;
    }

    public static void bootstrap() {
        // Deliberately empty: the hot render path must not allocate or touch disk.
    }

    /**
     * setupTerrain is the expensive visibility/queue preparation stage. We keep it intact,
     * but expose a cheap frame marker so later renderer stages can coalesce redundant work.
     */
    public static void setupTerrainEnter(Object renderGlobal, Object viewEntity, Object camera,
                                         int frameCount, boolean spectator) {
        // No reflective work here: this is intentionally a zero-cost marker.
    }

    /**
     * Translucent geometry does not need to be resorted for sub-block camera movement.
     * Vanilla can enqueue a resort repeatedly while the player is moving smoothly.
     * A small spatial threshold removes those redundant tasks without disabling resorting.
     */
    public static boolean allowTransparencyResort(Object chunk, float x, float y, float z) {
        if (!ZorbixConfig.smartAnimations) return true;
        synchronized (TRANSPARENCY_CAMERA) {
            CameraPoint previous = TRANSPARENCY_CAMERA.get(chunk);
            if (previous != null) {
                float dx = x - previous.x;
                float dy = y - previous.y;
                float dz = z - previous.z;
                if (dx * dx + dy * dy + dz * dz < 0.0625F) return false;
            }
            TRANSPARENCY_CAMERA.put(chunk, new CameraPoint(x, y, z));
        }
        return true;
    }

    /** Coalesce repeated transparency-only queue requests for a very short window. */
    public static boolean allowTransparencyUpdate(Object chunk) {
        if (!ZorbixConfig.smartAnimations || chunk == null) return true;
        long now = System.nanoTime();
        synchronized (TRANSPARENCY_QUEUE) {
            Long previous = TRANSPARENCY_QUEUE.get(chunk);
            if (previous != null && now - previous.longValue() < ZorbixConfig.transparencyCoalesceNs) {
                return false;
            }
            TRANSPARENCY_QUEUE.put(chunk, Long.valueOf(now));
        }
        return true;
    }

    public static boolean allowClouds() { return ZorbixConfig.clouds; }
    public static boolean allowWeather() { return ZorbixConfig.weather; }
    public static boolean allowParticles() { return !ZorbixConfig.minimalParticles; }
}
