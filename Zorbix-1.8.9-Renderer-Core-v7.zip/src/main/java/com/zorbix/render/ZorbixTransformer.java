package com.zorbix.render;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.commons.AdviceAdapter;
import org.objectweb.asm.commons.Method;

/** Runtime bytecode patches for a clean vanilla 1.8.9 installation. */
public final class ZorbixTransformer implements ClassFileTransformer {
    private static final String ENTITY = "net/minecraft/client/renderer/EntityRenderer";
    private static final String GLOBAL = "net/minecraft/client/renderer/RenderGlobal";
    private static final String DISPATCHER = "net/minecraft/client/renderer/chunk/ChunkRenderDispatcher";
    private static final String RENDER_CHUNK = "net/minecraft/client/renderer/chunk/RenderChunk";

    private static boolean is(String name, String named, String obf) {
        return named.equals(name) || obf.equals(name);
    }

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                            ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (className == null || classfileBuffer == null) return null;
        try {
            // 1.8.9 SRG/obfuscated names verified against the MCP mappings: buq/bfr/bho/bht.
            if (is(className, ENTITY, "buq")) return patchEntity(classfileBuffer);
            if (is(className, GLOBAL, "bfr")) return patchGlobal(classfileBuffer);
            if (is(className, DISPATCHER, "bho")) return patchDispatcher(classfileBuffer);
            if (is(className, RENDER_CHUNK, "bht")) return patchRenderChunk(classfileBuffer);
        } catch (Throwable ignored) {
            // An optional optimization must never prevent vanilla from starting.
        }
        return null;
    }

    private byte[] patchEntity(byte[] bytes) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cr.accept(new Visitor(cw) {
            @Override public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(access, name, desc, sig, ex);
                if ("(IFJ)V".equals(desc)) {
                    return new AdviceAdapter(Opcodes.ASM9, mv, access, name, desc) {
                        @Override protected void onMethodEnter() {
                            invokeStatic(Type.getObjectType("com/zorbix/render/ZorbixRender"),
                                    new Method("bootstrap", "()V"));
                        }
                    };
                }
                return mv;
            }
        }, 0);
        return cw.toByteArray();
    }

    private byte[] patchGlobal(byte[] bytes) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cr.accept(new Visitor(cw) {
            @Override public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(access, name, desc, sig, ex);

                // Vanilla 1.8.9 RenderGlobal.updateChunks(long) is void, not boolean.
                if ("(J)V".equals(desc)) {
                    return new AdviceAdapter(Opcodes.ASM9, mv, access, name, desc) {
                        @Override protected void onMethodEnter() {
                            loadArg(0);
                            invokeStatic(Type.getObjectType("com/zorbix/render/ZorbixRender"),
                                    new Method("clampDeadline", "(J)J"));
                            storeArg(0);
                        }
                    };
                }

                // RenderGlobal.setupTerrain(Entity, double, ICamera, int, boolean).
                if (isSetupTerrainDescriptor(desc)) {
                    return new AdviceAdapter(Opcodes.ASM9, mv, access, name, desc) {
                        @Override protected void onMethodEnter() {
                            loadThis();
                            loadArg(0);
                            loadArg(2);
                            loadArg(3);
                            loadArg(4);
                            invokeStatic(Type.getObjectType("com/zorbix/render/ZorbixRender"),
                                    new Method("setupTerrainEnter", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V"));
                        }
                    };
                }
                return mv;
            }
        }, 0);
        return cw.toByteArray();
    }

    private static boolean isSetupTerrainDescriptor(String desc) {
        if (desc == null || !desc.endsWith(")V")) return false;
        Type[] args;
        try { args = Type.getArgumentTypes(desc); } catch (Throwable t) { return false; }
        if (args.length != 5) return false;
        return args[0].getSort() == Type.OBJECT
                && args[1].getSort() == Type.DOUBLE
                && args[2].getSort() == Type.OBJECT
                && args[3].getSort() == Type.INT
                && args[4].getSort() == Type.BOOLEAN;
    }

    private byte[] patchDispatcher(byte[] bytes) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cr.accept(new Visitor(cw) {
            @Override public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(access, name, desc, sig, ex);

                // Render-thread OpenGL upload drain.
                if ("(J)Z".equals(desc)) {
                    return new AdviceAdapter(Opcodes.ASM9, mv, access, name, desc) {
                        @Override protected void onMethodEnter() {
                            loadArg(0);
                            invokeStatic(Type.getObjectType("com/zorbix/render/ZorbixRender"),
                                    new Method("clampDeadline", "(J)J"));
                            storeArg(0);
                        }
                    };
                }

                // updateTransparencyLater(RenderChunk) is a safe place to coalesce duplicate
                // transparency-only rebuilds. It does not discard normal chunk rebuilds.
                if (isRenderChunkOneArg(desc)) {
                    return new AdviceAdapter(Opcodes.ASM9, mv, access, name, desc) {
                        @Override protected void onMethodEnter() {
                            loadArg(0);
                            invokeStatic(Type.getObjectType("com/zorbix/render/ZorbixRender"),
                                    new Method("allowTransparencyUpdate", "(Ljava/lang/Object;)Z"));
                            Label proceed = new Label();
                            ifZCmp(Opcodes.NE, proceed);
                            push(false);
                            returnValue();
                            visitLabel(proceed);
                        }
                    };
                }
                return mv;
            }
        }, 0);
        return cw.toByteArray();
    }

    private static boolean isRenderChunkOneArg(String desc) {
        if (desc == null || !desc.endsWith(")Z")) return false;
        Type[] args;
        try { args = Type.getArgumentTypes(desc); } catch (Throwable t) { return false; }
        if (args.length != 1 || args[0].getSort() != Type.OBJECT) return false;
        String n = args[0].getInternalName();
        return RENDER_CHUNK.equals(n) || "bht".equals(n);
    }

    private byte[] patchRenderChunk(byte[] bytes) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cr.accept(new Visitor(cw) {
            @Override public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(access, name, desc, sig, ex);
                if ("(FFFLnet/minecraft/client/renderer/chunk/ChunkCompileTaskGenerator;)V".equals(desc)
                        || "(FFFLbhn;)V".equals(desc)) {
                    return new AdviceAdapter(Opcodes.ASM9, mv, access, name, desc) {
                        @Override protected void onMethodEnter() {
                            loadThis();
                            loadArg(0);
                            loadArg(1);
                            loadArg(2);
                            invokeStatic(Type.getObjectType("com/zorbix/render/ZorbixRender"),
                                    new Method("allowTransparencyResort", "(Ljava/lang/Object;FFF)Z"));
                            Label proceed = new Label();
                            ifZCmp(Opcodes.NE, proceed);
                            visitInsn(Opcodes.RETURN);
                            visitLabel(proceed);
                        }
                    };
                }
                return mv;
            }
        }, 0);
        return cw.toByteArray();
    }

    private abstract static class Visitor extends ClassVisitor {
        Visitor(ClassVisitor next) { super(Opcodes.ASM9, next); }
    }
}
