# Zorbix 1.8.9 Renderer Core v4

The goal is stable frame pacing, not a fake FPS counter.

The patch works around the vanilla 1.8.9 terrain pipeline: `EntityRenderer` calls `RenderGlobal.setupTerrain`, then `RenderGlobal.updateChunks`, then the block layers are rendered. The update deadline is clamped so chunk work and GL uploads cannot consume an uncontrolled amount of the current frame. setupTerrain is also instrumented by its 5-argument signature, while translucent resorting is spatially coalesced instead of being disabled outright.

## Build
Use GitHub Actions from `.github/workflows/build.yml`.

## Runtime config
`%APPDATA%/.minecraft/config/zorbix.properties` on Windows, or `~/.minecraft/config/zorbix.properties` elsewhere.
